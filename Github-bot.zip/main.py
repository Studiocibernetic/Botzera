import discord
import feedparser
import asyncio
import os
from dotenv import load_dotenv

# Carrega as variáveis do ambiente do arquivo .env
load_dotenv()

# Definindo os intents
intents = discord.Intents.default()
intents.messages = True

TOKEN = os.getenv('DISCORD_TOKEN')  # Obtém o token do ambiente
CHANNEL_ID = 1295935150382907402
feed_url = 'https://f95zone.to/forums/-/index.rss'
last_post_title = None

client = discord.Client(intents=intents)

async def check_feed():
    global last_post_title
    await client.wait_until_ready()
    channel = client.get_channel(CHANNEL_ID)

    if channel is None:
        print(f"Erro: Canal com ID {CHANNEL_ID} não encontrado.")
        return

    while not client.is_closed():
        feed = feedparser.parse(feed_url)
        latest_entry = feed.entries[0]

        if last_post_title != latest_entry.title:
            last_post_title = latest_entry.title
            await channel.send(f"Nova postagem: {latest_entry.title}\n{latest_entry.link}")

        await asyncio.sleep(60)

@client.event
async def on_ready():
    print(f'Logged in as {client.user}')
    client.loop.create_task(check_feed())

async def main():
    await client.start(TOKEN)

if __name__ == "__main__":
    asyncio.run(main())